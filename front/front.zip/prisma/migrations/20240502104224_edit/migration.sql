-- AlterTable
ALTER TABLE "Restaurant" ALTER COLUMN "crousId" DROP DEFAULT;
